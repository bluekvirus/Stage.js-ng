/*
 * This is where you would set up your app.
 * The entrypoint file for your app to bundle
 */

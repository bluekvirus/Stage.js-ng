/*
 * This is where you would set up your app.
 * The entrypoint file for your app to bundle
 * Place your entrypoint imports within here.
 * @author Cherie Huang
 */


//example of how to import view modules
// import './view/view1/view1.js';
